#include "arduino_secrets.h"

/*
 * MOBIPET - AVANCAR ETAPA DO ATENDIMENTO
 * -----------------------------------------
 * Fluxo:
 *   1. Aproxima o cartao ja cadastrado
 *   2. ESP32 le o ID do pet gravado no bloco 4
 *   3. ESP32 envia o ID do pet para a API Laravel
 *   4. API identifica o agendamento do dia daquele pet e
 *      avanca a etapa (Pendente -> Em atendimento -> Concluido)
 *   5. Buzzer: 1 bipe = sucesso | 3 bipes = negado/erro
 *
 * IMPORTANTE: instale a biblioteca "ArduinoJson" (by Benoit Blanchon)
 * pelo Gerenciador de Bibliotecas da Arduino IDE antes de compilar.
 */

#include <SPI.h>
#include <MFRC522.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

/* DEFINICAO DOS PINOS
| RC522        | ESP32 DevKit V1 | Funcao              |
| ------------ | --------------: | ------------------- |
| **SDA / SS** |      GPIO **5** | Chip Select         |
| **SCK**      |     GPIO **18** | Clock SPI           |
| **MOSI**     |     GPIO **23** | Dados ESP32 -> RC522|
| **MISO**     |     GPIO **19** | Dados RC522 -> ESP32|
| **IRQ**      |    Nao conectar | Interrupcao         |
| **GND**      |             GND | Terra               |
| **RST**      |     GPIO **22** | Reset               |
| **3.3V**     |         **3V3** | Alimentacao         |
| **BUZZER**   |      GPIO **4** | Sinal sonoro        |
*/

#define SS_PIN     5
#define RST_PIN    22
#define BUZZER_PIN 4

MFRC522 rfid(SS_PIN, RST_PIN);
MFRC522::MIFARE_Key key;

// Bloco onde o ID do pet foi gravado no cadastro
byte bloco = 4;

// -------------------------------
// CONFIGURACAO - AJUSTE AQUI
// -------------------------------
const char* WIFI_SSID     = "WIFI-EDUC";
const char* WIFI_PASSWORD = "ac3ce7ss0-EDUC";

// Endpoint da API Laravel que avanca a etapa do agendamento do pet
// Rota: POST /api/atendimentos/avancar-rfid Body: {"pet_id": 123, "uid": "..."}
const char* serverName = "http://10.141.131.113:8000/api/agendamentos/avancar-rfid";

// Tempo minimo entre leituras do mesmo cartao (evita leitura duplicada)
unsigned long ultimaLeitura = 0;
const unsigned long INTERVALO_MINIMO = 3000;



// -------------------------------
// SETUP
// -------------------------------

void setup() {

  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  conectarWiFi();

  SPI.begin();
  rfid.PCD_Init();

  for (byte i = 0; i < 6; i++) {
    key.keyByte[i] = 0xFF;
  }

  Serial.println();
  Serial.println("============================================================");
  Serial.println("                         M O B I P E T");
  Serial.println("                 SISTEMA DE ATENDIMENTO RFID");
  Serial.println("============================================================");
  Serial.println();
  Serial.println("------------------------------------------------------------");
  Serial.println("                    AGUARDANDO CARTAO...");
  Serial.println("             Aproxime o cartao do leitor RFID");
  Serial.println("------------------------------------------------------------");
}



// -------------------------------
// LOOP
// -------------------------------

void loop() {

  if (!rfid.PICC_IsNewCardPresent()) {
    return;
  }

  if (!rfid.PICC_ReadCardSerial()) {
    return;
  }

  // Evita leituras repetidas em sequencia rapida
  if (millis() - ultimaLeitura < INTERVALO_MINIMO) {
    finalizarCartao();
    return;
  }
  ultimaLeitura = millis();

  Serial.println();
  Serial.println();
  Serial.println("============================================================");
  Serial.println("                     CARTAO DETECTADO");
  Serial.println("============================================================");
  Serial.println();

  String uid = obterUID();

  Serial.println("  +------------------------------------------------------+");
  Serial.print("  | UID DO CARTAO : ");
  Serial.print(uid);

  int espacosUid = 34 - uid.length();

  for (int i = 0; i < espacosUid; i++) {
    Serial.print(" ");
  }

  Serial.println("|");
  Serial.println("  +------------------------------------------------------+");

  // -------------------------------
  // LE O ID DO PET GRAVADO NO CARTAO
  // -------------------------------

  String petId = lerBloco(bloco);

  if (petId == "") {

    Serial.println();
    Serial.println("------------------------------------------------------------");
    Serial.println("                       ! ATENCAO !");
    Serial.println("------------------------------------------------------------");
    Serial.println();
    Serial.println("  [ERRO] Cartao vazio ou nao cadastrado.");
    Serial.println();
    Serial.println("  Verifique o cadastro do cartao no sistema.");
    Serial.println();
    Serial.println("------------------------------------------------------------");

    bipNegado();
    finalizarCartao();

    Serial.println();
    Serial.println("                    Aproxime outro cartao...");
    Serial.println("============================================================");

    return;
  }

  Serial.println();
  Serial.println("  PET ID LIDO    : " + petId);

  Serial.println();
  Serial.println("------------------------------------------------------------");
  Serial.println("               ATUALIZANDO ATENDIMENTO");
  Serial.println("------------------------------------------------------------");
  Serial.println();
  Serial.println("  > Enviando dados para o sistema...");
  Serial.println("  > Pet ID : " + petId);
  Serial.println("  > UID    : " + uid);
  Serial.println();

  // -------------------------------
  // ENVIA PARA A API AVANCAR A ETAPA
  // -------------------------------

  bool sucesso = enviarDados(petId, uid);

  Serial.println();

  if (sucesso) {

    Serial.println("------------------------------------------------------------");
    Serial.println("                 [ OK ] OPERACAO CONCLUIDA");
    Serial.println("------------------------------------------------------------");
    Serial.println();
    Serial.println("  O atendimento do pet foi atualizado com sucesso.");
    Serial.println();
    Serial.println("------------------------------------------------------------");

    bipSucesso();

  } else {

    Serial.println("------------------------------------------------------------");
    Serial.println("                 [ERRO] OPERACAO FALHOU");
    Serial.println("------------------------------------------------------------");
    Serial.println();
    Serial.println("  Nao foi possivel atualizar o atendimento.");
    Serial.println();
    Serial.println("  Verifique:");
    Serial.println("    - Conexao WiFi");
    Serial.println("    - Cadastro do cartao");
    Serial.println("    - Atendimento do pet");
    Serial.println("    - Servidor da API");
    Serial.println();
    Serial.println("------------------------------------------------------------");

    bipNegado();
  }

  finalizarCartao();

  Serial.println();
  Serial.println("============================================================");
  Serial.println("                    M O B I P E T");
  Serial.println("------------------------------------------------------------");
  Serial.println("                 Aproxime outro cartao...");
  Serial.println("============================================================");
}



// =====================================================
// CONECTA AO WIFI
// =====================================================

void conectarWiFi() {

  Serial.println();
  Serial.println("============================================================");
  Serial.println("                    INICIANDO M O B I P E T");
  Serial.println("============================================================");
  Serial.println();

  Serial.print("  [ WIFI ] Conectando");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println();
  Serial.println("  [ OK ] WiFi conectado!");
  Serial.print("  [ IP  ] ");
  Serial.println(WiFi.localIP());

  Serial.println();
}



// =====================================================
// MONTA O UID DO CARTAO COMO STRING (formato hex)
// =====================================================

String obterUID() {

  String uidStr = "";

  for (byte i = 0; i < rfid.uid.size; i++) {

    if (rfid.uid.uidByte[i] < 0x10) {
      uidStr += "0";
    }

    uidStr += String(rfid.uid.uidByte[i], HEX);
  }

  uidStr.toUpperCase();

  return uidStr;
}



// =====================================================
// LE OS DADOS DO BLOCO DO CARTAO
// =====================================================

String lerBloco(byte bloco) {

  byte buffer[18];
  byte tamanho = sizeof(buffer);

  MFRC522::StatusCode status;

  status = rfid.PCD_Authenticate(
    MFRC522::PICC_CMD_MF_AUTH_KEY_A,
    bloco,
    &key,
    &(rfid.uid)
  );

  if (status != MFRC522::STATUS_OK) {

    Serial.println();
    Serial.println("  [ERRO] Falha na autenticacao do cartao.");
    Serial.print("  Detalhes: ");
    Serial.println(rfid.GetStatusCodeName(status));

    return "";
  }

  status = rfid.MIFARE_Read(bloco, buffer, &tamanho);

  if (status != MFRC522::STATUS_OK) {

    Serial.println();
    Serial.println("  [ERRO] Falha na leitura do cartao.");
    Serial.print("  Detalhes: ");
    Serial.println(rfid.GetStatusCodeName(status));

    return "";
  }

  String dado = "";

  for (byte i = 0; i < 16; i++) {

    // So aceita digitos, ja que o dado gravado e um ID numerico
    if (buffer[i] >= '0' && buffer[i] <= '9') {
      dado += (char)buffer[i];
    }
  }

  return dado;
}



// =====================================================
// ENVIA O PET ID + UID PARA A API AVANCAR A ETAPA
// Retorna true se a API confirmou o avanco (HTTP 200-299)
// =====================================================

bool enviarDados(String petId, String uid) {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("  [ERRO] WiFi desconectado.");

    return false;
  }

  HTTPClient http;

  http.begin(serverName);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> doc;

  doc["pet_id"] = petId.toInt();
  doc["uid"] = uid;

  String json;
  serializeJson(doc, json);

  Serial.println("  JSON ENVIADO:");
  Serial.println("  " + json);
  Serial.println();

  int httpCode = http.POST(json);

  Serial.print("  HTTP STATUS : ");
  Serial.println(httpCode);

  if (httpCode > 0) {

    String resposta = http.getString();

    Serial.println();
    Serial.println("  RESPOSTA DA API:");
    Serial.println("  " + resposta);
  }

  http.end();

  return (httpCode >= 200 && httpCode < 300);
}



// =====================================================
// FINALIZA A COMUNICACAO COM O CARTAO
// =====================================================

void finalizarCartao() {
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}



// =====================================================
// BUZZER - 1 BIPE LONGO (SUCESSO)
// =====================================================

void bipSucesso() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(250);
  digitalWrite(BUZZER_PIN, LOW);
}



// =====================================================
// BUZZER - 3 BIPES CURTOS (NEGADO / NAO CADASTRADO / ERRO NA API)
// =====================================================

void bipNegado() {
  for (byte i = 0; i < 3; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(100);
    digitalWrite(BUZZER_PIN, LOW);
    delay(100);
  }
}