#include <SPI.h>
#include <MFRC522.h>

/* DEFINIÃÃO DOS PINOS
| RC522        | ESP32 DevKit V1 | FunÃ§Ã£o              |
| ------------ | --------------: | ------------------- |
| **SDA / SS** |      GPIO **5** | Chip Select         |
| **SCK**      |     GPIO **18** | Clock SPI           |
| **MOSI**     |     GPIO **23** | Dados ESP32 â RC522 |
| **MISO**     |     GPIO **19** | Dados RC522 â ESP32 |
| **IRQ**      |    NÃ£o conectar | InterrupÃ§Ã£o         |
| **GND**      |             GND | Terra               |
| **RST**      |     GPIO **22** | Reset               |
| **3.3V**     |         **3V3** | AlimentaÃ§Ã£o         |
*/

#define SS_PIN   5
#define RST_PIN  22

MFRC522 rfid(SS_PIN, RST_PIN);

// Chave padrÃ£o dos cartÃµes MIFARE
MFRC522::MIFARE_Key key;

// Bloco onde vamos armazenar os dados
byte bloco = 4;

// VariÃ¡vel que armazenarÃ¡ o texto digitado
String mensagem = "";

// -------------------------------
// SETUP
// -------------------------------

void setup() {

  Serial.begin(115200);

  // Inicializa SPI
  SPI.begin();

  // Inicializa RC522
  rfid.PCD_Init();

  // Configura chave padrÃ£o
  for (byte i = 0; i < 6; i++) {
    key.keyByte[i] = 0xFF;
  }

  Serial.println();
  Serial.println();
  Serial.println("================================================");
  Serial.println("              M O B I P E T");
  Serial.println("          SISTEMA DE GRAVACAO RFID");
  Serial.println("================================================");
  Serial.println();
  Serial.println("  [ESP32] + [RC522]  |  MIFARE");
  Serial.println("------------------------------------------------");
  Serial.println("  Sistema inicializado com sucesso.");
  Serial.println();
  Serial.println("  Digite o valor que deseja gravar");
  Serial.println("  e pressione ENTER.");
  Serial.println();
  Serial.print("  > ");
}

// -------------------------------
// LOOP
// -------------------------------

void loop() {

  // ---------------------------------
  // 1. VERIFICA SE O USUARIO DIGITOU
  // ---------------------------------

  if (Serial.available() > 0) {

    mensagem = Serial.readStringUntil('\n');

    // Remove espaÃ§os e quebras de linha
    mensagem.trim();

    if (mensagem.length() == 0) {

      Serial.println();
      Serial.println();
      Serial.println("  [!] ATENCAO");
      Serial.println("  ------------------------------------------------");
      Serial.println("  Nenhum valor foi digitado.");
      Serial.println("  Digite um valor valido.");
      Serial.println("  ------------------------------------------------");
      Serial.println();
      Serial.print("  > ");

      return;
    }

    // Um bloco MIFARE possui somente 16 bytes
    if (mensagem.length() > 16) {

      Serial.println();
      Serial.println();
      Serial.println("  [X] ERRO DE VALIDACAO");
      Serial.println("  ------------------------------------------------");
      Serial.println("  O valor informado possui mais de 16 caracteres.");
      Serial.println("  Limite permitido: 16 caracteres.");
      Serial.println("  ------------------------------------------------");
      Serial.println();

      mensagem = "";

      Serial.print("  > ");

      return;
    }

    Serial.println();
    Serial.println();
    Serial.println("================================================");
    Serial.println("              NOVA GRAVACAO RFID");
    Serial.println("================================================");
    Serial.println();
    Serial.print("  Valor: ");
    Serial.println(mensagem);
    Serial.print("  Tamanho: ");
    Serial.print(mensagem.length());
    Serial.println(" caracteres");
    Serial.println();
    Serial.println("  [>] Aproxime o cartao RFID...");
    Serial.println();
  }

  // ---------------------------------
  // 2. SE NÃO TEM VALOR, NÃO FAZ NADA
  // ---------------------------------

  if (mensagem.length() == 0) {
    return;
  }

  // ---------------------------------
  // 3. VERIFICA SE EXISTE UM CARTÃO
  // ---------------------------------

  if (!rfid.PICC_IsNewCardPresent()) {
    return;
  }

  // ---------------------------------
  // 4. TENTA LER O CARTÃO
  // ---------------------------------

  if (!rfid.PICC_ReadCardSerial()) {
    return;
  }

  Serial.println();
  Serial.println("================================================");
  Serial.println("              CARTAO DETECTADO");
  Serial.println("================================================");
  Serial.println();

  // ---------------------------------
  // 5. MOSTRA UID
  // ---------------------------------

  Serial.print("  UID: ");

  for (byte i = 0; i < rfid.uid.size; i++) {

    if (rfid.uid.uidByte[i] < 0x10) {
      Serial.print("0");
    }

    Serial.print(rfid.uid.uidByte[i], HEX);
    Serial.print(" ");
  }

  Serial.println();

  // ---------------------------------
  // 6. MOSTRA TIPO DO CARTÃO
  // ---------------------------------

  MFRC522::PICC_Type tipo;

  tipo = (MFRC522::PICC_Type)rfid.uid.sak;

  Serial.print("  Tipo: ");
  Serial.println(rfid.PICC_GetTypeName(tipo));

  Serial.print("  Bloco: ");
  Serial.println(bloco);

  Serial.println();
  Serial.println("  [>] Preparando gravacao...");
  Serial.println();

  // ---------------------------------
  // 7. GRAVA O VALOR
  // ---------------------------------

  Serial.print("  Gravando valor: ");
  Serial.println(mensagem);

  if (gravarBloco(bloco, mensagem)) {

    Serial.println();
    Serial.println("  +------------------------------------------+");
    Serial.println("  |       GRAVACAO CONCLUIDA COM SUCESSO    |");
    Serial.println("  +------------------------------------------+");

  } else {

    Serial.println();
    Serial.println("  +------------------------------------------+");
    Serial.println("  |          ERRO AO GRAVAR OS DADOS        |");
    Serial.println("  +------------------------------------------+");
  }

  // ---------------------------------
  // 8. LÃ O VALOR GRAVADO
  // ---------------------------------

  Serial.println();
  Serial.println("  [>] Verificando dados gravados...");
  Serial.println();

  lerBloco(bloco);

  // ---------------------------------
  // 9. FINALIZA CARTÃO
  // ---------------------------------

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  // Limpa a mensagem
  mensagem = "";

  Serial.println();
  Serial.println("================================================");
  Serial.println("              OPERACAO FINALIZADA");
  Serial.println("================================================");
  Serial.println();
  Serial.println("  O cartao pode ser removido.");
  Serial.println();
  Serial.println("  Digite outro valor para uma nova gravacao.");
  Serial.println();
  Serial.print("  > ");
}

// =====================================================
// FUNÃÃO PARA GRAVAR DADOS
// =====================================================

bool gravarBloco(byte bloco, String texto) {

  MFRC522::StatusCode status;

  // AutenticaÃ§Ã£o do bloco
  status = rfid.PCD_Authenticate(
    MFRC522::PICC_CMD_MF_AUTH_KEY_A,
    bloco,
    &key,
    &(rfid.uid)
  );

  if (status != MFRC522::STATUS_OK) {

    Serial.println();
    Serial.println("  [X] FALHA NA AUTENTICACAO");
    Serial.print("  Motivo: ");
    Serial.println(rfid.GetStatusCodeName(status));

    return false;
  }

  // Buffer de 16 bytes
  byte dados[16];

  // Limpa o buffer
  memset(dados, 0, sizeof(dados));

  // Copia o texto para o buffer
  texto.getBytes(dados, sizeof(dados));

  // Grava no cartÃ£o
  status = rfid.MIFARE_Write(
    bloco,
    dados,
    16
  );

  if (status != MFRC522::STATUS_OK) {

    Serial.println();
    Serial.println("  [X] FALHA NA GRAVACAO");
    Serial.print("  Motivo: ");
    Serial.println(rfid.GetStatusCodeName(status));

    return false;
  }

  return true;
}

// =====================================================
// FUNÃÃO PARA LER DADOS
// =====================================================

void lerBloco(byte bloco) {

  byte buffer[18];
  byte tamanho = sizeof(buffer);

  MFRC522::StatusCode status;

  // AutenticaÃ§Ã£o
  status = rfid.PCD_Authenticate(
    MFRC522::PICC_CMD_MF_AUTH_KEY_A,
    bloco,
    &key,
    &(rfid.uid)
  );

  if (status != MFRC522::STATUS_OK) {

    Serial.println("  [X] FALHA NA AUTENTICACAO");
    Serial.print("  Motivo: ");
    Serial.println(rfid.GetStatusCodeName(status));

    return;
  }

  // Leitura
  status = rfid.MIFARE_Read(
    bloco,
    buffer,
    &tamanho
  );

  if (status != MFRC522::STATUS_OK) {

    Serial.println("  [X] FALHA NA LEITURA");
    Serial.print("  Motivo: ");
    Serial.println(rfid.GetStatusCodeName(status));

    return;
  }

  Serial.println("  +------------------------------------------+");
  Serial.println("  |              DADOS DO CARTAO            |");
  Serial.println("  +------------------------------------------+");

  Serial.println();

  Serial.print("  Texto gravado: ");

  // Mostra os caracteres
  for (byte i = 0; i < 16; i++) {

    if (buffer[i] >= 32 && buffer[i] <= 126) {
      Serial.print((char)buffer[i]);
    }
  }

  Serial.println();

  // Mostra os bytes em hexadecimal
  Serial.print("  HEX: ");

  for (byte i = 0; i < 16; i++) {

    if (buffer[i] < 0x10) {
      Serial.print("0");
    }

    Serial.print(buffer[i], HEX);
    Serial.print(" ");
  }

  Serial.println();
}